# Join_Tabel_Mysql_-_PHP
Tugas Matakuliah Praktikum Dan Basis Data

Didalam File berisikan 
- Index.php
- Koneksi.php
- Database.sq.l

Requirments 
- Ubuntu Server 18.04 ( Web Server Service )
- MySql / MariaDB Terbaru
- PHP 7.2.24.0Ubuntu0.18.04.7
- Apache2

Thanks
